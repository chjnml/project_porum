-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2018 at 10:07 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `porum`
--
CREATE DATABASE IF NOT EXISTS `porum` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `porum`;

-- --------------------------------------------------------

--
-- Table structure for table `answerstbl`
--

CREATE TABLE `answerstbl` (
  `answerID` int(11) NOT NULL,
  `questionID` int(11) NOT NULL,
  `answereeID` int(11) NOT NULL,
  `comments` varchar(10000) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answerstbl`
--

INSERT INTO `answerstbl` (`answerID`, `questionID`, `answereeID`, `comments`, `datetime`) VALUES
(1, 1, 1256, 'Everytime You\'re Near?', '2018-04-05 03:47:15'),
(2, 1, 1256, 'Just Like Me. They Long To Be. Close To You.', '2018-04-05 03:47:36'),
(3, 1, 1256, 'Dadadada..', '2018-04-05 03:49:03'),
(4, 2, 1256, 'My Neighbour Celebrated Her 16th Birthday Recently.\r\n\r\nHappy, Her Parents Gifted Her A Laptop.\r\n\r\nIdeally, One Should Have Been Excited But She Was Upset With Parents Because They Didn\'t Get Her The &lsquo;expensive&rsquo; One.\r\n\r\nEventually, Her Parents Bought Her Another One But The Happiness Of ?gifting&rsquo; Something To Daughter Had Vanished From Their Faces.\r\n\r\nNow, I Won\'t Discuss Whether Having A Laptop Was Necessary Or Not Because I Know, The Lines Between Need And Greed Is Slowly Getting Blurred In Present Times.\r\n\r\nWhat Disturbs Me Most, Is The Attitude Of Feeling Entitled To All Luxuries Of Life.\r\n\r\nI Remember, While We Were Growing Up, We Used To Get Happy At Every Gift Irrespective Of Its Size.\r\n\r\nBecause Somewhere We Had This Realisation That We Were Already Blessed Enough To Have The Things That Our Parents Never Had.\r\n\r\nNow, We Just Care Enough To Know The Price Tag Of A Gift But Not The Struggle And Sacrifice Of Those Gifting It To Us.\r\n\r\nAnd, That\'s Sad.', '2018-04-05 03:56:44');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `postsID` int(20) NOT NULL,
  `questions` varchar(500) NOT NULL,
  `datetime` datetime NOT NULL,
  `dateModified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `postsID`, `questions`, `datetime`, `dateModified`) VALUES
(1, 1256, 'Why Do Birds Sudenly Appear?', '2018-04-05 03:44:06', '2018-04-05 03:49:03'),
(2, 1256, 'What Is The Sad Reality Of Our Generation?', '2018-04-05 03:48:52', '2018-04-05 03:56:44');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `studentID` int(20) NOT NULL,
  `codec` varchar(300) NOT NULL,
  `email` varchar(30) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `verify` varchar(500) NOT NULL,
  `activation_key` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`studentID`, `codec`, `email`, `last_name`, `first_name`, `middle_name`, `verify`, `activation_key`) VALUES
(1234, '$2y$10$UxOM6CuMgLUJbL6wRLNcounoqiKgLfHy.bODKysrdZOfJ/l8dzGl2', 'xyz@example.com', 'Administrator', 'Account', 'Only', '1', ''),
(1256, '$2y$10$gzFWtJNHv3VhQpL2TPKo4e/zDV//aMKq8HZdu1EcPw4PW29VJlJjW', 'requiemofsouls18@gmail.com', 'Parone', 'Mark Lindon', 'Advincula', '1', '564314f7755dc6a2a9a999a9a2b35106');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answerstbl`
--
ALTER TABLE `answerstbl`
  ADD PRIMARY KEY (`answerID`),
  ADD KEY `questionID` (`questionID`),
  ADD KEY `answereeID` (`answereeID`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postsID` (`postsID`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`studentID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answerstbl`
--
ALTER TABLE `answerstbl`
  MODIFY `answerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answerstbl`
--
ALTER TABLE `answerstbl`
  ADD CONSTRAINT `answerstbl_ibfk_1` FOREIGN KEY (`questionID`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `answerstbl_ibfk_2` FOREIGN KEY (`answereeID`) REFERENCES `student_info` (`studentID`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`postsID`) REFERENCES `student_info` (`studentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
date_default_timezone_set('Asia/Manila');
include 'connection/connection-string.php';
include 'postClass.php';


if(!isset($_SESSION['name']))
{
	header('location: index');
}

$getQuestion = new post();
$myquestion = $getQuestion->getQuestion(htmlentities($_GET['id']));
$questionID = htmlentities($_GET['id']);

if(isset($_POST['post_answer']))
{
	$opAnswer = ucwords(htmlentities($_POST['answer']));
	$OP = $_SESSION['studentID'];
	
	$_date = date("Y-m-d h:i:sa");
	$posting = array($OP, $opAnswer, $questionID, $_date);

	$getQuestion->postAnswer($posting);
	$update_dateModified = $getQuestion->modify_date($_date, $questionID);
	header("location:".$_SERVER[REQUEST_URI]);
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>PorumOverflow - Tulongan tayo!</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="../images/icons/logo.png">
	<link rel="stylesheet" href="../dist/font-awesome/css/font-awesome.css">	
	<link rel="stylesheet" href="../dist/local.css">
	<link rel="stylesheet" href="../dist/bootstrap-3.3.7-dist/css/bootstrap.css">
	<script src="../dist/bootstrap-3.3.7-dist/js/jquery.min.js"></script>
	<script src="../dist/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
	

</head>
<body>
	<div class="mobile-header">
		<img src="../images/porum_logo.png">
	</div>
	<ul class="mobile-nav">
		<li class="mobile-nav-list"><a href="#" onclick="openNav()"><span class="fa fa-navicon"></span></a></li>
		<li class="mobile-nav-list"><a href="../home"><span class="fa fa-newspaper-o"></span></a></li>
		<li class="mobile-nav-list"><a href="#"><span class="fa fa-plus-circle"></span></a></li>
		<li class="mobile-nav-list"><a href="#"><span class="fa fa-gear"></span></a></li>
	</ul>
	<div id="mySidenav" class="sidenav">
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		<a href="#">Profile</a>		
		<a href="../logout">Logout</a>
	</div>

	<div class="container-fluid">
		<div class="media-wrapper"> <!-- Ask Question button -->
			<div class="media">				
				<div class="media-body">
					<h1 class="media-heading"><p><?php echo $myquestion ?></p></h1>
					<hr>
					<form method="post" action="">
						<div class="form-group">
							<textarea class="form-control" style="height:50px;" name="answer"></textarea>							
						</div>
						<button type="submit" class="btn" name="post_answer">Answer</button>
					</form>
				</div>
			</div>
		</div>
		<?php
		$result = $db->prepare('SELECT 
			student_info.first_name, student_info.middle_name, student_info.last_name, answerstbl.comments, answerstbl.datetime 
			FROM answerstbl
			INNER JOIN student_info ON student_info.studentID = answerstbl.answereeID 
			WHERE answerstbl.questionID = ?			
			ORDER by datetime DESC');
		$result->execute([$questionID]);

		foreach ($result as $row) {


			echo '<div class="media-wrapper">
			<div class="media">
			<div class="media-left">
			<img src="../images/User.png" class="media-object img-circle" style="width:20px">					
			</div>
			<div class="media-body">
			<div class="media-heading">
			<small>
			<a href="#" class="text-muted">'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a> <br>posted· 
			'.date("F t", strtotime($row['datetime'])).'
			</small>
			</div>
			<p class="text-left">'.$row['comments'].'</p>
			

			</div>
			</div>			
			</div>';
		}
		?>
		


	</div>



</body>
</html>

<script type="text/javascript">

	function openNav() {
		document.getElementById("mySidenav").style.width = "250px";
		document.getElementById("main").style.marginLeft = "250px";

	}

	function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("main").style.marginLeft= "0";

	}

</script>



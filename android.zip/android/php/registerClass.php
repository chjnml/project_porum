<?php
class register 
{
	private $db;	
	public function __construct()
	{
		
		require 'connection/connection-string.php';
		$this->db = $db;
		

	}
	public function new_user($values)
	{
		
		$db = $this->db;
		$columns = array(
			"studentID","codec","email","last_name",
			"first_name","middle_name","verify"
		);

		$placeholders = substr(str_repeat('?,', sizeOf($columns)), 0, -1);

		$result = $db->prepare(
			sprintf(
				"INSERT INTO student_info (%s) VALUES (%s)", 				
				implode(',', $columns), 
				$placeholders
			)
		);

		$result->execute($values);
		return $result->rowCount();
	}

	public function update_activation($code, $id)
	{
		$db = $this->db;
		$result = $db->prepare('UPDATE student_info SET activation_key = ? WHERE studentID = ?');
		$result->execute([$code, $id]);

		return $result->rowCount();
	}

	public function activate($key)
	{
		$db = $this->db;
		$result = $db->prepare('SELECT * FROM student_info WHERE activation_key = ? and verify = 0');
		$result->execute([$key]);

		if($result->rowCount() > 0)
		{
			foreach ($result as $row) {
				$student = $row['studentID'];				
			}
			$update = $db->prepare('UPDATE student_info SET verify = 1 WHERE studentID = ?');
			$update->execute([$student]);

			$up_count = $update->rowCount();
		}

		return $up_count;

	}


}
?>
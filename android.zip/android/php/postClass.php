<?php
class post {
	
	private $db;	
	public function __construct()
	{
		
		require 'connection/connection-string.php';
		$this->db = $db;
		

	}

	public function new_post($values)
	{
		$db = $this->db;
		$columns = array(
			"postsID","questions","datetime", "dateModified"
		);

		$placeholders = substr(str_repeat('?,', sizeOf($columns)), 0, -1);

		$result = $db->prepare(
			sprintf(
				"INSERT INTO posts (%s) VALUES (%s)", 				
				implode(',', $columns), 
				$placeholders
			)
		);

		$result->execute($values);
		return $result->rowCount();
	}

	public function getQuestion($id)
	{
		$db = $this->db;
		$result = $db->prepare('SELECT questions FROM posts WHERE id = ?');
		$result->execute([$id]);

		foreach ($result as $row) {
			$theQuestion = $row['questions'];
		}
		return $theQuestion;
	}

	public function postAnswer($values)
	{
		$db = $this->db;
		$columns = array(
			"answereeID","comments","questionID", "datetime"
		);

		$placeholders = substr(str_repeat('?,', sizeOf($columns)), 0, -1);

		$result = $db->prepare(
			sprintf(
				"INSERT INTO answerstbl (%s) VALUES (%s)", 				
				implode(',', $columns), 
				$placeholders
			)
		);

		$result->execute($values);
		return $result->rowCount();
	}

	public function modify_date($date, $id)
	{
		$db = $this->db;
		$result = $db->prepare('UPDATE posts SET dateModified = ? WHERE id = ?');
		$result->execute([$date, $id]);
		
	}

}
?>
<?php
include 'connection/connection-string.php';
include 'registerClass.php';
$notice = "";
if(isset($_POST['activateBtn']))
{
	$verify = new register();

	$activation = htmlentities($_POST['activation_code']);

	$count = $verify->activate($activation);

	if($count > 0)
	{
		header('location: ../home');
		exit();
	}




}	




?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Porum Overflow - Activate Account</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="../images/icons/logo.png"/>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../dist/util.css">
	<link rel="stylesheet" type="text/css" href="../dist/main.css">
	<!--===============================================================================================-->
</head>
<body>

	<div class="limiter">
		<div class="container-login100">


			<form class="login100-form validate-form" action="" method="post">
				<span class="login100-form-title">
					Please input activation code that was sent to your email.
				</span>

				

				<div class="wrap-input100 validate-input" data-validate = "Activation Code required">
					<input class="input100" type="text" name="activation_code">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-lock" aria-hidden="true"></i>
					</span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" name="activateBtn">
						Send
					</button>
				</div>

				


			</form>

		</div>
	</div>




	<!--===============================================================================================-->	
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<!--===============================================================================================-->
	<script src="../dist/js/main.js"></script>

</body>
</html>
<?php
include 'connection/connection-string.php';
include 'registerClass.php';
$notice = "";
if(isset($_POST['register']))
{

	if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
	{
		$email = htmlentities($_POST['email'], ENT_QUOTES);		
		$studentID = htmlentities($_POST['studentID'], ENT_QUOTES);
		$f_name = htmlentities($_POST['fname'], ENT_QUOTES);
		$m_name = htmlentities($_POST['mname'], ENT_QUOTES);
		$l_name = htmlentities($_POST['lname'], ENT_QUOTES);
		$code = password_hash(htmlentities($_POST['pass']), PASSWORD_BCRYPT, array("cost" => 10));
		$new_user = array($studentID, $code, $email,  $l_name, $f_name, $m_name, '0');

		$register = new register();
		$count = $register->new_user($new_user);

		if($count > 0)
		{
			$key = md5(microtime().rand());

			$register->update_activation($key, $studentID);

			$to = $email;
			$subject = 'Verify your Porum Account';
			$message = 'Activation code: '.$key.''.$studentID;
			$headers = 'FROM: Porum';
			mail($to, $subject, $message, $headers);

			header("location: activation_page");
			exit();


		}


	}
	else
	{
		$notice = "<div class='alert alert-danger'><strong>Error!</strong> Invalid email</div>";
	}
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Porum Overflow - New User</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="../images/icons/logo.png"/>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../dist/util.css">
	<link rel="stylesheet" type="text/css" href="../dist/main.css">
	<!--===============================================================================================-->
</head>
<body>

	<div class="limiter">
		<div class="container-login100">


			<form class="login100-form validate-form" method="post" action="">
				<span class="login100-form-title">
					Create a New Account 
				</span>

				<div class="wrap-input100 validate-input" data-validate = "Student ID is required">
					<input class="input100" type="number" name="studentID" placeholder="Student ID" min="0">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-id-card-o" aria-hidden="true"></i>
					</span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "This is a required field">
					<input class="input100" type="text" name="fname" placeholder="First Name">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "This is a required field">
					<input class="input100" type="text" name="lname" placeholder="Last Name">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "This is a required field">
					<input class="input100" type="text" name="mname" placeholder="Middle Name">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
				</div>


				<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
					<input class="input100" type="text" name="email" placeholder="Email">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-envelope" aria-hidden="true"></i>
					</span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Password is required">
					<input class="input100" type="password" name="pass" placeholder="Password">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-lock" aria-hidden="true"></i>
					</span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" name="register">
						Register
					</button>
				</div>

				<div class="text-center p-t-12">
					<span class="txt1">
						<a class="txt1" href="../index">
							Already registered?
						</a>
					</span>

				</div>


			</form>

		</div>
	</div>




	<!--===============================================================================================-->	
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<!--===============================================================================================-->
	<script src="../dist/js/main.js"></script>

</body>
</html>
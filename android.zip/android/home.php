<?php
session_start();
date_default_timezone_set('Asia/Manila');
include 'php/connection/connection-string.php';
include 'php/postClass.php';

if(!isset($_SESSION['name']))
{
	header('location: index');
}


if(isset($_POST['addquestion']))
{
$new_post = new post();
$OP = $_SESSION['studentID'];
$question = ucwords(htmlentities($_POST['myquestion']));
$OP_datetime = date("Y-m-d h:i:sa");
$for_post = array($OP, $question, $OP_datetime, $OP_datetime);

$new_post->new_post($for_post); 
header('Location: '.$_SERVER[REQUEST_URI]);	
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>PorumOverflow - Tulongan tayo!</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="images/icons/logo.png">
	<link rel="stylesheet" href="dist/font-awesome/css/font-awesome.css">	
	<link rel="stylesheet" href="dist/local.css">
	<link rel="stylesheet" href="dist/bootstrap-3.3.7-dist/css/bootstrap.css">
	<script src="dist/bootstrap-3.3.7-dist/js/jquery.min.js"></script>
	<script src="dist/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
	

</head>
<body>
	<div class="mobile-header">
		<img src="images/porum_logo.png">
	</div>
	<ul class="mobile-nav">
		<li class="mobile-nav-list"><a href="#" onclick="openNav()"><span class="fa fa-navicon"></span></a></li>
		<li class="mobile-nav-list"><a href="#"><span class="fa fa-newspaper-o"></span></a></li>
		<li class="mobile-nav-list"><a href="#"><span class="fa fa-plus-circle"></span></a></li>
		<li class="mobile-nav-list"><a href="#"><span class="fa fa-gear"></span></a></li>
	</ul>
	<div id="mySidenav" class="sidenav">
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		<a href="#">Profile</a>		
		<a href="logout">Logout</a>
	</div>

	<div class="container-fluid">
		<div class="media-wrapper"> <!-- Ask Question button -->
			<div class="media">
				<div class="media-left">
					<img src="images/User.png" class="media-object" style="width:20px">
				</div>
				<div class="media-body">
					<p class="media-heading"><?php echo $_SESSION['name'] ?></p>
					<a href="#askModal" class="text-muted" data-toggle="modal"><strong>What is your question?</strong></a>
				</div>
			</div>
		</div>
		<?php
		$result = $db->prepare('SELECT 
			student_info.first_name, student_info.middle_name, student_info.last_name, posts.questions, posts.datetime, posts.id as keyID 
			FROM posts
			LEFT JOIN student_info ON student_info.studentID = posts.postsID ORDER by dateModified DESC');
		$result->execute();

		foreach ($result as $row) {


			echo '<div class="media-wrapper">
			<div class="media">
			<div class="media-left">
			<img src="images/User.png" class="media-object img-circle" style="width:20px">					
			</div>
			<div class="media-body">
			<div class="media-heading">
			<small>
			<a href="#" class="text-muted">'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a> <br>posted· 
			'.date("F t Y h:i:sa", strtotime($row['datetime'])).'
			</small>
			</div>
			<a href="php/question?id='.$row['keyID'].'" class="text-muted"><p class="questions text-justify">'.$row['questions'].'</p></a>
			
								
			</div>
			</div>			
			</div>';
		}
		?>
		


	</div>



</body>
</html>

<script type="text/javascript">

	function openNav() {
		document.getElementById("mySidenav").style.width = "250px";
		document.getElementById("main").style.marginLeft = "250px";

	}

	function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("main").style.marginLeft= "0";

	}

</script>

<div id="askModal" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">
					<div class="media">
						<div class="media-left">
							<img src="images/User.png" class="media-object" style="width:20px">
						</div>
						<div class="media-body">
							<p class="media-heading"><?php echo $_SESSION['name'] ?> asks:</p>											
						</div>
					</div>
				</h4>
			</div>
			<div class="modal-body">
				<form method="post" action="">
					<div class="form-group">
						<textarea class="form-control" name="myquestion" placeholder="Start questions with 'What', 'How', 'Why', etc"></textarea>
					</div>

					<hr>

					

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="submit" class="btn btn-primary" name="addquestion">Add Question</button>
				</div>
			</div>
		</form>	
	</div>
</div>

<?php
session_start();
require_once "php/connection/connection-string.php";
date_default_timezone_set('Asia/Manila');

session_destroy();
header("location: index");


?>